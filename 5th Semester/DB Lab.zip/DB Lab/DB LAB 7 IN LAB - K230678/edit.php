<?php
include('action.php');
if (isset($_GET['eid'])) {
    $empId = $_GET['eid'];
    $query = $conn->prepare("SELECT * FROM employees WHERE id = :id");
    $query->bindParam("id", $empId);
    $query->execute();
    $employee = $query->fetch(PDO::FETCH_ASSOC);
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Employee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<div class="container mt-4">
    <h2>Edit Employee</h2>
    <form method="post">
        <input type="hidden" name="empId" value="<?= $employee['id'] ?>">
        <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-control" name="empName" value="<?= $employee['name'] ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" class="form-control" name="empEmail" value="<?= $employee['email'] ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Department</label>
            <input type="text" class="form-control" name="empDept" value="<?= $employee['department'] ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Designation</label>
            <input type="text" class="form-control" name="empDesig" value="<?= $employee['designation'] ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Salary</label>
            <input type="number" class="form-control" name="empSalary" value="<?= $employee['salary'] ?>" required>
        </div>
        <button type="submit" name="UpdateEmployee" class="btn btn-primary">Update Employee</button>
    </form>
</div>
</body>
</html>
