<?php
$serverName = "mysql:host=localhost;dbname=payrolldb";
$dbUser = "root";
$dbPass = "";

try {
    $conn = new PDO($serverName, $dbUser, $dbPass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully!";
} catch (PDOException $error) {
    echo "Connection failed: " . $error->getMessage();
}
?>
