<?php include('action.php'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Employee Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<div class="container mt-4">
    <h2>Employee Records</h2>
    <a href="add.php" class="btn btn-success mb-3">Add Employee</a>
    <table class="table table-striped">
        <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Designation</th>
            <th>Salary</th>
            <th colspan="2">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $query = $conn->query("SELECT * FROM employees");
        $employees = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($employees as $emp) { ?>
            <tr>
                <td><?= $emp['id'] ?></td>
                <td><?= $emp['name'] ?></td>
                <td><?= $emp['email'] ?></td>
                <td><?= $emp['department'] ?></td>
                <td><?= $emp['designation'] ?></td>
                <td><?= $emp['salary'] ?></td>
                <td><a href="edit.php?eid=<?= $emp['id'] ?>" class="btn btn-warning">Edit</a></td>
                <td><a href="action.php?delete=<?= $emp['id'] ?>" class="btn btn-danger">Delete</a></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>
